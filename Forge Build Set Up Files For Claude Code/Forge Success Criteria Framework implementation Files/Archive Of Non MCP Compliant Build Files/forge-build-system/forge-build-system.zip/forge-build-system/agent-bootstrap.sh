#!/bin/bash
# .forge/agent-bootstrap.sh
# 
# TRUE RALPH LOOP Build System
# Each task = FRESH session (no context rot)
#
# Based on "Lost in the Middle" research (Liu et al., 2023)
# and Ralph Loop principles from Pete Huang

set -e

FORGE_DIR="$(dirname "$0")"
PROGRESS_FILE="$FORGE_DIR/progress.md"
CURRENT_EPIC_FILE="$FORGE_DIR/current-epic.txt"
CURRENT_TASK_FILE="$FORGE_DIR/current-task.txt"

# Epic definitions
EPIC_NAMES=(
  ""  # 0 index placeholder
  "foundation"
  "answer-contract"
  "forge-c-core"
  "convergence"
  "figma-parser"
  "react-generator"
  "test-generation"
  "evidence-packs"
  "infrastructure"
  "platform-ui"
  "integrations"
  "e2e-testing"
)

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

print_header() {
  echo ""
  echo -e "${CYAN}╔════════════════════════════════════════════════════════════╗${NC}"
  echo -e "${CYAN}║  FORGE B-D Platform - True Ralph Loop Build System         ║${NC}"
  echo -e "${CYAN}║  Each task = Fresh session (peak performance)              ║${NC}"
  echo -e "${CYAN}╚════════════════════════════════════════════════════════════╝${NC}"
  echo ""
}

get_current_epic() {
  if [ -f "$CURRENT_EPIC_FILE" ]; then
    cat "$CURRENT_EPIC_FILE"
  else
    echo "1"
  fi
}

get_epic_name() {
  local num=$1
  echo "${EPIC_NAMES[$num]}"
}

cmd_task() {
  print_header
  
  local epic=$(get_current_epic)
  local epic_name=$(get_epic_name $epic)
  local epic_dir="$FORGE_DIR/epics/epic-$(printf "%02d" $epic)-$epic_name"
  
  # Get next uncompleted task from progress.md
  local task=""
  if [ -f "$PROGRESS_FILE" ]; then
    task=$(grep -m1 "^- \[ \]" "$PROGRESS_FILE" 2>/dev/null | sed 's/- \[ \] //' || true)
  fi
  
  if [ -z "$task" ]; then
    echo -e "${GREEN}✅ All tasks in Epic $epic ($epic_name) complete!${NC}"
    echo ""
    echo "Run: .forge/agent-bootstrap.sh next-epic"
    return 0
  fi
  
  # Save current task
  echo "$task" > "$CURRENT_TASK_FILE"
  
  echo -e "${YELLOW}📋 NEXT TASK${NC}"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo ""
  echo -e "  ${BLUE}$task${NC}"
  echo ""
  echo -e "${YELLOW}📁 EPIC${NC}"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo ""
  echo "  Epic $epic: $epic_name"
  echo ""
  echo -e "${RED}⚠️  IMPORTANT: Start a NEW Claude Code session!${NC}"
  echo ""
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo ""
  echo "In the NEW session, give Claude this context:"
  echo ""
  echo -e "${CYAN}────────────────────────────────────────────────────────────${NC}"
  echo ""
  echo "Read these files for context:"
  echo "1. .forge/progress.md (current state)"
  echo "2. .forge/epics/epic-$(printf "%02d" $epic)-$epic_name/TASKS.md (task details)"
  echo ""
  echo "Your task: $task"
  echo ""
  echo "Instructions:"
  echo "- Complete ONLY this task"
  echo "- Update progress.md when done (mark task [x])"
  echo "- Add notes about what you did"
  echo "- EXIT when complete - do NOT continue to next task"
  echo ""
  echo -e "${CYAN}────────────────────────────────────────────────────────────${NC}"
  echo ""
}

cmd_status() {
  print_header
  
  local epic=$(get_current_epic)
  local epic_name=$(get_epic_name $epic)
  
  echo -e "${YELLOW}Build Status${NC}"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo ""
  
  # Count tasks
  local completed=0
  local remaining=0
  
  if [ -f "$PROGRESS_FILE" ]; then
    completed=$(grep -c "^\- \[x\]" "$PROGRESS_FILE" 2>/dev/null || echo 0)
    remaining=$(grep -c "^\- \[ \]" "$PROGRESS_FILE" 2>/dev/null || echo 0)
  fi
  
  local total=$((completed + remaining))
  
  echo "  Current Epic: $epic - $epic_name"
  echo "  Tasks: $completed/$total complete"
  echo ""
  
  # Progress bar
  if [ "$total" -gt 0 ]; then
    local pct=$((completed * 100 / total))
    local filled=$((completed * 30 / total))
    local empty=$((30 - filled))
    
    printf "  ["
    for i in $(seq 1 $filled); do printf "█"; done
    for i in $(seq 1 $empty); do printf "░"; done
    printf "] %d%%\n" $pct
  fi
  
  echo ""
  
  # Current task
  local current=""
  if [ -f "$PROGRESS_FILE" ]; then
    current=$(grep -m1 "^- \[ \]" "$PROGRESS_FILE" 2>/dev/null | sed 's/- \[ \] //' || true)
  fi
  
  if [ -n "$current" ]; then
    echo -e "  ${BLUE}Next Task:${NC} $current"
  else
    echo -e "  ${GREEN}All tasks complete!${NC}"
  fi
  
  echo ""
}

cmd_complete_task() {
  local task="$1"
  
  if [ -z "$task" ]; then
    # Try to get from current task file
    if [ -f "$CURRENT_TASK_FILE" ]; then
      task=$(cat "$CURRENT_TASK_FILE")
    fi
  fi
  
  if [ -z "$task" ]; then
    echo -e "${RED}Error: No task specified${NC}"
    echo ""
    echo "Usage: .forge/agent-bootstrap.sh complete-task 'Task X.Y.Z: Description'"
    echo "   or: Update progress.md directly to mark [x]"
    return 1
  fi
  
  # Mark task complete in progress.md
  if [ -f "$PROGRESS_FILE" ]; then
    # Escape special characters for sed
    local escaped_task=$(echo "$task" | sed 's/[\/&]/\\&/g')
    sed -i "s/- \[ \] $escaped_task/- [x] $escaped_task/" "$PROGRESS_FILE"
  fi
  
  echo -e "${GREEN}✅ Task marked complete${NC}"
  echo ""
  echo "To continue:"
  echo "  1. Exit this session"
  echo "  2. Start a NEW session"
  echo "  3. Run: .forge/agent-bootstrap.sh task"
  echo ""
}

cmd_next_epic() {
  local current=$(get_current_epic)
  local next=$((current + 1))
  
  if [ "$next" -gt 12 ]; then
    echo ""
    echo -e "${GREEN}🎉 ALL EPICS COMPLETE!${NC}"
    echo ""
    echo "The FORGE B-D Platform build is finished."
    echo ""
    echo "Final steps:"
    echo "  1. Run E2E tests: pnpm test:e2e"
    echo "  2. Set up demo environment"
    echo "  3. Record demo video"
    echo ""
    return 0
  fi
  
  # Update current epic
  echo "$next" > "$CURRENT_EPIC_FILE"
  
  local next_name=$(get_epic_name $next)
  local prev_name=$(get_epic_name $current)
  
  echo ""
  echo -e "${GREEN}✅ Epic $current ($prev_name) complete!${NC}"
  echo ""
  echo -e "${YELLOW}Starting Epic $next: $next_name${NC}"
  echo ""
  
  # Check for handoff prompt
  local handoff="$FORGE_DIR/prompts/handoff-$(printf "%02d" $current)-to-$(printf "%02d" $next).md"
  if [ -f "$handoff" ]; then
    echo "📖 Read the handoff prompt before starting:"
    echo "   $handoff"
    echo ""
  fi
  
  echo "To start:"
  echo "  1. Start a NEW session"
  echo "  2. Read the handoff prompt"
  echo "  3. Run: .forge/agent-bootstrap.sh task"
  echo ""
}

cmd_init() {
  print_header
  
  echo "Initializing FORGE build system..."
  echo ""
  
  # Create progress.md if it doesn't exist
  if [ ! -f "$PROGRESS_FILE" ]; then
    cat > "$PROGRESS_FILE" << 'PROGRESS_EOF'
# FORGE B-D Platform Build Progress

## Current State
- Epic: 1 (Foundation)
- Session: 1
- Total Tokens Used: 0
- Estimated Cost: $0.00

## Epic 1: Foundation - Task Progress

### Phase 1.1: Project Setup
- [ ] Task 1.1.1: Initialize pnpm monorepo with workspace config
- [ ] Task 1.1.2: Configure TypeScript 5.x with strict mode
- [ ] Task 1.1.3: Set up ESLint + Prettier with shared configs
- [ ] Task 1.1.4: Configure Husky pre-commit hooks

### Phase 1.2: Core Package
- [ ] Task 1.2.1: Create packages/core directory structure
- [ ] Task 1.2.2: Create shared TypeScript types (ForgeContext, etc.)
- [ ] Task 1.2.3: Create logger utility with createLogger function
- [ ] Task 1.2.4: Create TokenTracker utility for cost monitoring

### Phase 1.3: Build Infrastructure
- [ ] Task 1.3.1: Set up GitHub Actions CI workflow
- [ ] Task 1.3.2: Configure Turborepo for monorepo builds
- [ ] Task 1.3.3: Create package stub directories for all 11 packages

## Completed Tasks
(none yet)

## Blockers / Errors
(none)

## Patterns Learned
(document patterns here for future sessions)

## Session Log
| Session | Task | Tokens | Duration | Notes |
|---------|------|--------|----------|-------|
| 1 | Init | 0 | - | Build system initialized |
PROGRESS_EOF
    echo "✅ Created progress.md"
  fi
  
  # Create current-epic.txt if it doesn't exist
  if [ ! -f "$CURRENT_EPIC_FILE" ]; then
    echo "1" > "$CURRENT_EPIC_FILE"
    echo "✅ Set current epic to 1"
  fi
  
  echo ""
  echo "Build system initialized!"
  echo ""
  echo "To start building:"
  echo "  .forge/agent-bootstrap.sh task"
  echo ""
}

cmd_help() {
  print_header
  
  echo "Usage: .forge/agent-bootstrap.sh <command>"
  echo ""
  echo "Commands:"
  echo "  task           Show next task (run at start of each session)"
  echo "  status         Show current build progress"
  echo "  complete-task  Mark current task complete"
  echo "  next-epic      Move to next epic (after all tasks done)"
  echo "  init           Initialize build system"
  echo "  help           Show this help"
  echo ""
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "TRUE RALPH LOOP WORKFLOW"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo ""
  echo "  ┌─────────────────────────────────────────┐"
  echo "  │ 1. Start NEW Claude Code session        │"
  echo "  │ 2. Run: .forge/agent-bootstrap.sh task  │"
  echo "  │ 3. Complete the ONE task shown          │"
  echo "  │ 4. Update progress.md                   │"
  echo "  │ 5. EXIT session                         │"
  echo "  │ 6. Repeat from step 1                   │"
  echo "  └─────────────────────────────────────────┘"
  echo ""
  echo "Why fresh sessions?"
  echo "  • Avoids 'context rot' (accuracy degrades >30K tokens)"
  echo "  • Each task gets full LLM attention (~8-15K tokens)"
  echo "  • Progress tracked in files, not conversation history"
  echo "  • Based on 'Lost in the Middle' research (Liu et al., 2023)"
  echo ""
}

# Command router
case "${1:-help}" in
  task|t)
    cmd_task
    ;;
  status|s)
    cmd_status
    ;;
  complete-task|complete|c)
    cmd_complete_task "$2"
    ;;
  next-epic|next|n)
    cmd_next_epic
    ;;
  init|i)
    cmd_init
    ;;
  help|--help|-h)
    cmd_help
    ;;
  *)
    echo "Unknown command: $1"
    echo "Run '.forge/agent-bootstrap.sh help' for usage."
    exit 1
    ;;
esac
