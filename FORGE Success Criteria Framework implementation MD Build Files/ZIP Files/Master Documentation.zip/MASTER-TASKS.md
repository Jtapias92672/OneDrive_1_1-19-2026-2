# FORGE B-D Platform: Master Epic Roadmap

> **For Claude Code Agents:** This is your navigation file. Each epic has a detailed TASKS.md.
> **ArcFoundry Skills:** atomic-task-breakdown + long-running-agent-harness patterns.

**Total Epics:** 14 (including split Epic 10)  
**Total Tasks:** ~137 atomic tasks  
**Total Token Budget:** 665K tokens  
**Estimated Duration:** 70 days (~2.5 months)

---

## Build Philosophy: True Ralph Loop

Each task is designed for a **single fresh Claude session** (~5-15 minutes, 5-15K tokens).

**Why fresh sessions?**
- Context rot begins at ~30-40K tokens
- Auto-compaction loses technical nuance
- Each task gets full LLM attention
- Based on "Lost in the Middle" research (Liu et al., 2023)

**Session Pattern:**
```
1. Start NEW Claude session
2. Run: .forge/agent-bootstrap.sh task
3. Read progress.md + current epic's TASKS.md
4. Complete ONE task
5. Update progress.md
6. EXIT session
7. REPEAT
```

---

## Epic Dependency Graph

```
                        Epic 1 (Foundation)
                              │
                              ▼
                        Epic 2 (Answer Contract)
                              │
              ┌───────────────┼───────────────┐
              │               │               │
              ▼               ▼               ▼
        Epic 5          Epic 3          Epic 9
      (Figma Parser)  (FORGE C Core)  (Infrastructure)
              │               │               │
              ▼               ▼               │
        Epic 6          Epic 3.75           │
    (React Generator) (Code Execution)      │
              │               │               │
              │               ▼               │
              │         Epic 4              │
              │     (Convergence) ◀─────────┘
              │          │ │
              │    ┌─────┘ └─────┐
              │    ▼             ▼
              │  Epic 7       Epic 8
              │ (Test Gen)  (Evidence Packs)
              │    │             │
              └────┼─────────────┘
                   │
                   ▼
           Epic 10a (Platform UI Core)
                   │
                   ▼
           Epic 10b (Platform UI Features)
                   │
                   ▼
             Epic 11 (Integrations)
                   │
                   ▼
             Epic 12 (E2E Testing)
```

---

## Token Budget by Epic

| Epic | Name | Tasks | Tokens | Days | Dependencies | Status |
|------|------|-------|--------|------|--------------|--------|
| 1 | Foundation | 11 | 40K | 3 | None | ⏳ |
| 2 | Answer Contract | 12 | 50K | 4 | Epic 1 | ⏳ |
| 3 | FORGE C Core | 12 | 60K | 5 | Epic 2 | ⏳ |
| 3.75 | Code Execution | 10 | 20K | 3 | Epic 3 | ⏳ |
| 4 | Convergence Engine | 14 | 70K | 6 | Epic 3.75 | ⏳ |
| 5 | Figma Parser | 10 | 50K | 5 | Epic 2 | ⏳ |
| 6 | React Generator | 12 | 60K | 5 | Epic 5 | ⏳ |
| 7 | Test Generation | 10 | 40K | 4 | Epic 4 | ⏳ |
| 8 | Evidence Packs | 8 | 35K | 3 | Epic 4 | ⏳ |
| 9 | Infrastructure | 12 | 55K | 5 | Epic 2 | ⏳ |
| 10a | Platform UI Core | 8 | 25K | 4 | Epic 4, 6, 9 | ⏳ |
| 10b | Platform UI Features | 8 | 25K | 4 | Epic 10a | ⏳ |
| 11 | Integrations | 10 | 40K | 5 | Epic 10b | ⏳ |
| 12 | E2E Testing | 10 | 45K | 5 | Epic 11 | ⏳ |
| **TOTAL** | | **~137** | **665K** | **70** | | |

---

## Individual Epic Files

Each epic has a detailed TASKS.md file:

```
epics/
├── epic-01-foundation/TASKS.md
├── epic-02-answer-contract/TASKS.md
├── epic-03-forge-c-core/TASKS.md
├── epic-03.75-code-execution/TASKS.md
├── epic-04-convergence/TASKS.md
├── epic-05-figma-parser/TASKS.md
├── epic-06-react-generator/TASKS.md
├── epic-07-test-generation/TASKS.md
├── epic-08-evidence-packs/TASKS.md
├── epic-09-infrastructure/TASKS.md
├── epic-10a-platform-ui-core/TASKS.md
├── epic-10b-platform-ui-features/TASKS.md
├── epic-11-integrations/TASKS.md
└── epic-12-e2e-testing/TASKS.md
```

---

## Session Workflow

### Starting a New Session

```bash
# 1. Navigate to project root
cd /path/to/forge-bd-platform

# 2. Run bootstrap script
.forge/agent-bootstrap.sh task

# 3. This will:
#    - Show current epic and task
#    - Display progress summary
#    - Load relevant TASKS.md context
```

### During the Session

1. Read the current task completely
2. Implement EXACTLY what's specified
3. Run verification commands
4. Confirm "Done When" criteria met

### Ending the Session

```bash
# 1. Update progress.md with task completion
# 2. Commit changes
git commit -m "Task X.Y.Z: [task name] - COMPLETE"

# 3. Exit session cleanly
# DO NOT start next task in same session
```

---

## Quick Reference: Task Format

```markdown
### Task X.Y.Z: [Descriptive Name]

**Time:** 5 minutes | **Tokens:** ~4K

**Files to CREATE:**
- `exact/path/to/file.ts`

**Purpose:** [One sentence why this task exists]

**Code:**
```typescript
// Complete implementation
```

**Verification:**
```bash
pnpm build && pnpm test
```

**Done When:** [Specific acceptance criteria]
```

---

## Master Completion Checklist

### Month 1: Core Engines (Weeks 1-4)
- [ ] Epic 1: Foundation (Days 1-3)
- [ ] Epic 2: Answer Contract (Days 4-7)
- [ ] Epic 3: FORGE C Core (Days 8-12)
- [ ] Epic 3.75: Code Execution (Days 13-15)
- [ ] Epic 4: Convergence Engine (Days 16-21)

### Month 2: Generation & Infrastructure (Weeks 5-8)
- [ ] Epic 5: Figma Parser (Days 22-26)
- [ ] Epic 6: React Generator (Days 27-31)
- [ ] Epic 7: Test Generation (Days 32-35)
- [ ] Epic 8: Evidence Packs (Days 36-38)
- [ ] Epic 9: Infrastructure (Days 39-43)

### Month 2.5: Platform & Integration (Weeks 9-10)
- [ ] Epic 10a: Platform UI Core (Days 44-47)
- [ ] Epic 10b: Platform UI Features (Days 48-51)
- [ ] Epic 11: Integrations (Days 52-56)
- [ ] Epic 12: E2E Testing (Days 57-61)

### Final Deliverables
- [ ] All packages build (`pnpm build`)
- [ ] All tests pass (`pnpm test`) with >80% coverage
- [ ] Documentation complete in each package
- [ ] Deployment guides in `docs/deployment/`
- [ ] Alpha release tagged `v0.1.0-alpha`

---

## Critical Rules

### DO
- ✅ Complete ONE task per session
- ✅ Verify before marking done
- ✅ Update progress.md after each task
- ✅ Commit with descriptive messages
- ✅ Exit session after task completion

### DON'T
- ❌ Work on multiple tasks in one session
- ❌ Skip verification steps
- ❌ Mark tasks done without testing
- ❌ Leave environment in broken state
- ❌ Exceed 15K tokens per session

---

## Recovery Procedures

### If Build Breaks
```bash
# Check what changed
git diff HEAD~3

# Run diagnostics
pnpm build --verbose 2>&1 | head -50

# If stuck, rollback
git reset --hard HEAD~1
```

### If Tests Fail
```bash
# Run specific failing test
pnpm test -- --grep "failing test name"

# Check test output
pnpm test -- --verbose
```

### If Context Exhausted
1. STOP immediately
2. Document current state in progress.md
3. Commit partial work: `git commit -m "WIP: Task X.Y.Z - partial"`
4. Exit session
5. Start fresh session to continue

---

## Package Map

```
packages/
├── core/               # @forge/core - Shared types, utils
├── answer-contract/    # @forge/answer-contract - Contract schema, validators
├── forge-c/            # @forge/forge-c - Main orchestrator
├── convergence/        # @forge/convergence - Convergence engine
├── figma-parser/       # @forge/figma-parser - Figma API integration
├── react-generator/    # @forge/react-generator - React code generation
├── test-generator/     # @forge/test-generator - Test generation
├── evidence-pack/      # @forge/evidence-pack - Compliance evidence
├── infrastructure/     # @forge/infrastructure - Deployment configs
├── integrations/       # @forge/integrations - Third-party integrations
└── platform-ui/        # @forge/platform-ui - Next.js dashboard
```

---

*Generated by atomic-task-breakdown + long-running-agent-harness skills*  
*Last Updated: 2026-01-16*
