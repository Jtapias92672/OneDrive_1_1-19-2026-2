#!/bin/bash
# FORGE Agent Bootstrap Script
# Usage: .forge/agent-bootstrap.sh [command]

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
PROGRESS_FILE="$SCRIPT_DIR/progress.md"
CURRENT_EPIC_FILE="$SCRIPT_DIR/current-epic.txt"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Get current epic number
get_current_epic() {
    if [ -f "$CURRENT_EPIC_FILE" ]; then
        cat "$CURRENT_EPIC_FILE"
    else
        echo "1"
    fi
}

# Get epic directory name from number
get_epic_dir() {
    local epic_num="$1"
    case "$epic_num" in
        1) echo "epic-01-foundation" ;;
        2) echo "epic-02-answer-contract" ;;
        3) echo "epic-03-forge-c-core" ;;
        3.75) echo "epic-03.75-code-execution" ;;
        4) echo "epic-04-convergence" ;;
        5) echo "epic-05-figma-parser" ;;
        6) echo "epic-06-react-generator" ;;
        7) echo "epic-07-test-generation" ;;
        8) echo "epic-08-evidence-packs" ;;
        9) echo "epic-09-infrastructure" ;;
        10a) echo "epic-10a-platform-ui-core" ;;
        10b) echo "epic-10b-platform-ui-features" ;;
        11) echo "epic-11-integrations" ;;
        12) echo "epic-12-e2e-testing" ;;
        *) echo "epic-$epic_num" ;;
    esac
}

# Show current task
show_task() {
    local epic=$(get_current_epic)
    local epic_dir=$(get_epic_dir "$epic")
    local tasks_file="$PROJECT_ROOT/epics/$epic_dir/TASKS.md"
    
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${GREEN}FORGE B-D Platform - Agent Bootstrap${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    echo -e "Current Epic: ${YELLOW}$epic${NC}"
    echo -e "Epic Directory: ${YELLOW}$epic_dir${NC}"
    echo ""
    
    if [ -f "$tasks_file" ]; then
        echo -e "${GREEN}Tasks File:${NC} epics/$epic_dir/TASKS.md"
        echo ""
        echo -e "${BLUE}Reading first uncompleted task...${NC}"
        echo ""
        # Show the first task header
        head -100 "$tasks_file"
    else
        echo -e "${RED}ERROR: Tasks file not found: $tasks_file${NC}"
        exit 1
    fi
    
    echo ""
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${YELLOW}Instructions:${NC}"
    echo "1. Read the current task from the TASKS.md file"
    echo "2. Implement EXACTLY what the task specifies"
    echo "3. Run verification commands"
    echo "4. Update progress.md when complete"
    echo "5. Commit changes"
    echo "6. EXIT this session"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
}

# Show progress summary
show_progress() {
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${GREEN}Progress Summary${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    
    if [ -f "$PROGRESS_FILE" ]; then
        cat "$PROGRESS_FILE"
    else
        echo "No progress file found. Starting fresh."
    fi
}

# Move to next epic
next_epic() {
    local current=$(get_current_epic)
    local next=""
    
    case "$current" in
        1) next="2" ;;
        2) next="3" ;;
        3) next="3.75" ;;
        3.75) next="4" ;;
        4) next="5" ;;
        5) next="6" ;;
        6) next="7" ;;
        7) next="8" ;;
        8) next="9" ;;
        9) next="10a" ;;
        10a) next="10b" ;;
        10b) next="11" ;;
        11) next="12" ;;
        12) 
            echo -e "${GREEN}🎉 All epics complete!${NC}"
            exit 0
            ;;
    esac
    
    echo "$next" > "$CURRENT_EPIC_FILE"
    echo -e "${GREEN}Moved to Epic $next${NC}"
    
    # Append to progress
    echo "" >> "$PROGRESS_FILE"
    echo "---" >> "$PROGRESS_FILE"
    echo "" >> "$PROGRESS_FILE"
    echo "## Epic $next Started - $(date '+%Y-%m-%d %H:%M')" >> "$PROGRESS_FILE"
}

# Initialize progress file
init_progress() {
    if [ ! -f "$PROGRESS_FILE" ]; then
        cat > "$PROGRESS_FILE" << 'EOF'
# FORGE B-D Platform - Progress Tracker

## Project Started
- Date: $(date '+%Y-%m-%d')
- Agent: Claude Code

---

## Epic 1: Foundation

### Tasks
- [ ] 1.1.1: Initialize pnpm monorepo
- [ ] 1.1.2: Configure TypeScript 5.x
- [ ] 1.1.3: Set up ESLint + Prettier
- [ ] 1.1.4: Configure Husky
- [ ] 1.2.1: Create packages/core structure
- [ ] 1.2.2: Create shared types
- [ ] 1.2.3: Create logger utility
- [ ] 1.2.4: Create TokenTracker utility
- [ ] 1.3.1: Set up GitHub Actions CI
- [ ] 1.3.2: Configure Turborepo
- [ ] 1.3.3: Create package stubs

### Notes
EOF
        echo -e "${GREEN}Progress file initialized${NC}"
    else
        echo -e "${YELLOW}Progress file already exists${NC}"
    fi
}

# Main command handler
case "${1:-task}" in
    task)
        show_task
        ;;
    progress)
        show_progress
        ;;
    next-epic)
        next_epic
        ;;
    init)
        init_progress
        echo "1" > "$CURRENT_EPIC_FILE"
        ;;
    help|--help|-h)
        echo "Usage: .forge/agent-bootstrap.sh [command]"
        echo ""
        echo "Commands:"
        echo "  task       Show current task (default)"
        echo "  progress   Show progress summary"
        echo "  next-epic  Move to next epic"
        echo "  init       Initialize progress tracking"
        echo "  help       Show this help"
        ;;
    *)
        echo -e "${RED}Unknown command: $1${NC}"
        echo "Run '.forge/agent-bootstrap.sh help' for usage"
        exit 1
        ;;
esac
