# Epic 1: Foundation - Atomic Task Breakdown

**Token Budget:** 40K (LIMIT: 40K) ✅ SAFE  
**Tasks:** 11  
**Estimated Time:** 3 days  
**Dependencies:** None

---

## Overview

Epic 1 establishes the monorepo foundation, shared TypeScript configuration, core utilities package, and CI/CD infrastructure. All subsequent epics depend on this foundation.

---

## Phase 1.1: Project Setup

### Task 1.1.1: Initialize pnpm monorepo with workspace config

**Time:** 5 minutes | **Tokens:** ~4K

**Files to CREATE:**
- `package.json` (root)
- `pnpm-workspace.yaml`
- `.npmrc`
- `.nvmrc`

**Purpose:** Establish the monorepo structure using pnpm workspaces.

**Implementation:**

```yaml
# pnpm-workspace.yaml
packages:
  - 'packages/*'
```

```json
// package.json (root)
{
  "name": "forge-bd-platform",
  "private": true,
  "packageManager": "pnpm@8.15.0",
  "engines": {
    "node": ">=20.0.0"
  },
  "scripts": {
    "build": "turbo build",
    "test": "turbo test",
    "lint": "turbo lint",
    "dev": "turbo dev",
    "format": "prettier --write .",
    "format:check": "prettier --check .",
    "typecheck": "turbo typecheck",
    "clean": "turbo clean && rm -rf node_modules"
  },
  "devDependencies": {
    "turbo": "^2.0.0"
  }
}
```

```ini
# .npmrc
auto-install-peers=true
strict-peer-dependencies=false
```

```
# .nvmrc
20
```

**Verification:**
```bash
pnpm install
pnpm -v  # Should show 8.x
node -v  # Should show v20.x
```

**Done When:** `pnpm install` runs without errors

---

### Task 1.1.2: Configure TypeScript 5.x with strict mode

**Time:** 5 minutes | **Tokens:** ~3K

**Files to CREATE:**
- `tsconfig.json` (root/base config)
- `tsconfig.build.json` (build-specific)

**Purpose:** Establish strict TypeScript configuration shared across all packages.

**Implementation:**

```json
// tsconfig.json
{
  "$schema": "https://json.schemastore.org/tsconfig",
  "compilerOptions": {
    "strict": true,
    "target": "ES2022",
    "module": "NodeNext",
    "moduleResolution": "NodeNext",
    "declaration": true,
    "declarationMap": true,
    "sourceMap": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "noUncheckedIndexedAccess": true,
    "noImplicitOverride": true,
    "paths": {
      "@forge/*": ["packages/*/src"]
    },
    "baseUrl": "."
  },
  "exclude": ["node_modules", "**/dist/**", "**/coverage/**"]
}
```

```json
// tsconfig.build.json
{
  "extends": "./tsconfig.json",
  "compilerOptions": {
    "noEmit": false,
    "declaration": true,
    "declarationMap": true,
    "sourceMap": true
  }
}
```

**Verification:**
```bash
pnpm add -Dw typescript@^5.0.0
pnpm exec tsc --version  # Should show 5.x
```

**Done When:** TypeScript 5.x installed and configured with strict mode

---

### Task 1.1.3: Set up ESLint + Prettier with shared configs

**Time:** 5 minutes | **Tokens:** ~4K

**Files to CREATE:**
- `eslint.config.js`
- `.prettierrc`
- `.prettierignore`

**Purpose:** Establish consistent code formatting and linting across all packages.

**Implementation:**

```javascript
// eslint.config.js
import eslint from '@eslint/js';
import tseslint from 'typescript-eslint';

export default tseslint.config(
  eslint.configs.recommended,
  ...tseslint.configs.strictTypeChecked,
  {
    languageOptions: {
      parserOptions: {
        project: true,
        tsconfigRootDir: import.meta.dirname,
      },
    },
    rules: {
      '@typescript-eslint/no-unused-vars': ['error', { argsIgnorePattern: '^_' }],
      '@typescript-eslint/no-explicit-any': 'error',
      '@typescript-eslint/explicit-function-return-type': 'warn',
      '@typescript-eslint/no-floating-promises': 'error',
    },
  },
  {
    ignores: ['**/dist/**', '**/node_modules/**', '**/coverage/**'],
  }
);
```

```json
// .prettierrc
{
  "semi": true,
  "singleQuote": true,
  "tabWidth": 2,
  "trailingComma": "es5",
  "printWidth": 100,
  "bracketSpacing": true,
  "arrowParens": "always"
}
```

```
# .prettierignore
node_modules
dist
coverage
pnpm-lock.yaml
*.md
```

**Dependencies:**
```bash
pnpm add -Dw eslint @eslint/js typescript-eslint prettier
```

**Verification:**
```bash
pnpm lint
pnpm format:check
```

**Done When:** Lint and format commands pass

---

### Task 1.1.4: Configure Husky pre-commit hooks

**Time:** 3 minutes | **Tokens:** ~2K

**Files to CREATE:**
- `.husky/pre-commit`
- `lint-staged.config.js`

**Purpose:** Enforce code quality checks before commits.

**Implementation:**

```bash
# .husky/pre-commit
#!/usr/bin/env sh
. "$(dirname -- "$0")/_/husky.sh"

pnpm exec lint-staged
```

```javascript
// lint-staged.config.js
export default {
  '*.{ts,tsx}': ['eslint --fix', 'prettier --write'],
  '*.{json,yaml,yml}': ['prettier --write'],
};
```

**Commands:**
```bash
pnpm add -Dw husky lint-staged
pnpm exec husky init
chmod +x .husky/pre-commit
```

**Verification:**
```bash
git init  # If not already a git repo
git add .
git commit -m "test" --dry-run
```

**Done When:** Pre-commit hook triggers lint-staged

---

## Phase 1.2: Core Package

### Task 1.2.1: Create packages/core directory structure

**Time:** 5 minutes | **Tokens:** ~3K

**Files to CREATE:**
- `packages/core/package.json`
- `packages/core/tsconfig.json`
- `packages/core/tsconfig.build.json`
- `packages/core/src/index.ts`
- `packages/core/src/types/index.ts`
- `packages/core/src/utils/index.ts`

**Purpose:** Create the @forge/core package that provides shared types and utilities.

**Implementation:**

```json
// packages/core/package.json
{
  "name": "@forge/core",
  "version": "0.1.0",
  "type": "module",
  "main": "./dist/index.js",
  "types": "./dist/index.d.ts",
  "exports": {
    ".": {
      "types": "./dist/index.d.ts",
      "import": "./dist/index.js"
    }
  },
  "files": ["dist"],
  "scripts": {
    "build": "tsc -p tsconfig.build.json",
    "test": "vitest run",
    "lint": "eslint src/",
    "typecheck": "tsc --noEmit",
    "clean": "rm -rf dist"
  },
  "devDependencies": {
    "vitest": "^1.0.0"
  }
}
```

```json
// packages/core/tsconfig.json
{
  "extends": "../../tsconfig.json",
  "compilerOptions": {
    "rootDir": "src",
    "outDir": "dist"
  },
  "include": ["src/**/*"],
  "exclude": ["node_modules", "dist", "**/*.test.ts"]
}
```

```json
// packages/core/tsconfig.build.json
{
  "extends": "./tsconfig.json",
  "compilerOptions": {
    "noEmit": false,
    "declaration": true,
    "declarationMap": true
  }
}
```

```typescript
// packages/core/src/index.ts
export * from './types/index.js';
export * from './utils/index.js';
```

```typescript
// packages/core/src/types/index.ts
// Types will be added in Task 1.2.2
export {};
```

```typescript
// packages/core/src/utils/index.ts
// Utils will be added in Tasks 1.2.3 and 1.2.4
export {};
```

**Verification:**
```bash
cd packages/core && pnpm build
```

**Done When:** Package builds without errors

---

### Task 1.2.2: Create shared TypeScript types

**Time:** 5 minutes | **Tokens:** ~5K

**Files to CREATE:**
- `packages/core/src/types/context.ts`
- `packages/core/src/types/config.ts`
- `packages/core/src/types/result.ts`
- Update `packages/core/src/types/index.ts`

**Purpose:** Define core types used across all FORGE packages.

**Implementation:**

```typescript
// packages/core/src/types/context.ts
export interface TokenUsage {
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
}

export interface ForgeContext {
  sessionId: string;
  projectId: string;
  timestamp: Date;
  config: ForgeConfig;
  tokens: TokenUsage;
}

export interface ForgeConfig {
  maxIterations: number;
  maxTokens: number;
  maxCost: number;
  providers: ProviderConfig[];
}

export interface ProviderConfig {
  name: string;
  model: string;
  apiKeyEnvVar: string;
  options?: Record<string, unknown>;
}
```

```typescript
// packages/core/src/types/result.ts
export interface ForgeError {
  code: string;
  message: string;
  details?: Record<string, unknown>;
  stack?: string;
}

export interface ResultMetadata {
  duration: number;
  iterations?: number;
  tokensUsed?: TokenUsage;
}

export type ForgeResult<T> = 
  | { success: true; data: T; metadata: ResultMetadata }
  | { success: false; error: ForgeError; metadata: ResultMetadata };

export function success<T>(data: T, metadata: Partial<ResultMetadata> = {}): ForgeResult<T> {
  return {
    success: true,
    data,
    metadata: { duration: 0, ...metadata },
  };
}

export function failure<T>(error: ForgeError, metadata: Partial<ResultMetadata> = {}): ForgeResult<T> {
  return {
    success: false,
    error,
    metadata: { duration: 0, ...metadata },
  };
}
```

```typescript
// packages/core/src/types/config.ts
export interface LogLevel {
  level: 'debug' | 'info' | 'warn' | 'error';
}

export interface PricingConfig {
  inputPer1k: number;
  outputPer1k: number;
  currency: string;
}

export const DEFAULT_PRICING: Record<string, PricingConfig> = {
  'claude-sonnet-4-20250514': {
    inputPer1k: 0.003,
    outputPer1k: 0.015,
    currency: 'USD',
  },
  'claude-opus-4-20250514': {
    inputPer1k: 0.015,
    outputPer1k: 0.075,
    currency: 'USD',
  },
};
```

```typescript
// packages/core/src/types/index.ts
export * from './context.js';
export * from './config.js';
export * from './result.js';
```

**Verification:**
```bash
cd packages/core && pnpm build
```

**Done When:** All types exported from @forge/core

---

### Task 1.2.3: Create logger utility

**Time:** 5 minutes | **Tokens:** ~4K

**Files to CREATE:**
- `packages/core/src/utils/logger.ts`
- Update `packages/core/src/utils/index.ts`

**Purpose:** Provide structured logging with namespaces and metadata.

**Implementation:**

```typescript
// packages/core/src/utils/logger.ts
export interface Logger {
  info(message: string, meta?: Record<string, unknown>): void;
  warn(message: string, meta?: Record<string, unknown>): void;
  error(message: string, meta?: Record<string, unknown>): void;
  debug(message: string, meta?: Record<string, unknown>): void;
}

export interface LogEntry {
  timestamp: string;
  level: string;
  namespace: string;
  message: string;
  meta?: Record<string, unknown>;
}

function formatLogEntry(entry: LogEntry): string {
  const metaStr = entry.meta ? ` ${JSON.stringify(entry.meta)}` : '';
  return `[${entry.timestamp}] [${entry.level.toUpperCase()}] [${entry.namespace}] ${entry.message}${metaStr}`;
}

export function createLogger(namespace: string): Logger {
  const log = (level: string, message: string, meta?: Record<string, unknown>): void => {
    const entry: LogEntry = {
      timestamp: new Date().toISOString(),
      level,
      namespace,
      message,
      meta,
    };
    
    const formatted = formatLogEntry(entry);
    
    switch (level) {
      case 'error':
        console.error(formatted);
        break;
      case 'warn':
        console.warn(formatted);
        break;
      case 'debug':
        if (process.env.DEBUG) {
          console.debug(formatted);
        }
        break;
      default:
        console.log(formatted);
    }
  };

  return {
    info: (message, meta) => log('info', message, meta),
    warn: (message, meta) => log('warn', message, meta),
    error: (message, meta) => log('error', message, meta),
    debug: (message, meta) => log('debug', message, meta),
  };
}

export const logger = createLogger('forge');
```

```typescript
// packages/core/src/utils/index.ts
export * from './logger.js';
```

**Verification:**
```bash
cd packages/core && pnpm build
node -e "import('@forge/core').then(m => m.logger.info('test', { key: 'value' }))"
```

**Done When:** Logger creates namespaced instances with structured output

---

### Task 1.2.4: Create TokenTracker utility

**Time:** 5 minutes | **Tokens:** ~5K

**Files to CREATE:**
- `packages/core/src/utils/tokens.ts`
- Update `packages/core/src/utils/index.ts`

**Purpose:** Track token usage and calculate costs across operations.

**Implementation:**

```typescript
// packages/core/src/utils/tokens.ts
import { TokenUsage, PricingConfig, DEFAULT_PRICING } from '../types/index.js';

export interface TokenReport {
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
  cost: number;
  currency: string;
  breakdown: {
    inputCost: number;
    outputCost: number;
  };
}

export class TokenTracker {
  private inputTokens = 0;
  private outputTokens = 0;
  private model: string;

  constructor(model: string = 'claude-sonnet-4-20250514') {
    this.model = model;
  }

  recordInput(tokens: number): void {
    this.inputTokens += tokens;
  }

  recordOutput(tokens: number): void {
    this.outputTokens += tokens;
  }

  record(usage: TokenUsage): void {
    this.inputTokens += usage.inputTokens;
    this.outputTokens += usage.outputTokens;
  }

  getTotal(): number {
    return this.inputTokens + this.outputTokens;
  }

  getUsage(): TokenUsage {
    return {
      inputTokens: this.inputTokens,
      outputTokens: this.outputTokens,
      totalTokens: this.getTotal(),
    };
  }

  getCost(pricing?: PricingConfig): number {
    const p = pricing ?? DEFAULT_PRICING[this.model] ?? DEFAULT_PRICING['claude-sonnet-4-20250514'];
    const inputCost = (this.inputTokens / 1000) * p.inputPer1k;
    const outputCost = (this.outputTokens / 1000) * p.outputPer1k;
    return inputCost + outputCost;
  }

  getReport(pricing?: PricingConfig): TokenReport {
    const p = pricing ?? DEFAULT_PRICING[this.model] ?? DEFAULT_PRICING['claude-sonnet-4-20250514'];
    const inputCost = (this.inputTokens / 1000) * p.inputPer1k;
    const outputCost = (this.outputTokens / 1000) * p.outputPer1k;

    return {
      inputTokens: this.inputTokens,
      outputTokens: this.outputTokens,
      totalTokens: this.getTotal(),
      cost: inputCost + outputCost,
      currency: p.currency,
      breakdown: {
        inputCost,
        outputCost,
      },
    };
  }

  reset(): void {
    this.inputTokens = 0;
    this.outputTokens = 0;
  }
}

export function countTokens(text: string): number {
  // Approximate token count: ~4 characters per token
  return Math.ceil(text.length / 4);
}
```

```typescript
// packages/core/src/utils/index.ts
export * from './logger.js';
export * from './tokens.js';
```

**Verification:**
```bash
cd packages/core && pnpm build
node -e "
import('@forge/core').then(m => {
  const tracker = new m.TokenTracker();
  tracker.recordInput(1000);
  tracker.recordOutput(500);
  console.log(tracker.getReport());
})
"
```

**Done When:** TokenTracker calculates costs correctly

---

## Phase 1.3: Build Infrastructure

### Task 1.3.1: Set up GitHub Actions CI workflow

**Time:** 5 minutes | **Tokens:** ~4K

**Files to CREATE:**
- `.github/workflows/ci.yml`

**Purpose:** Automated CI pipeline for all PRs and pushes.

**Implementation:**

```yaml
# .github/workflows/ci.yml
name: CI

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main, develop]

concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true

jobs:
  build:
    name: Build & Test
    runs-on: ubuntu-latest
    
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Setup pnpm
        uses: pnpm/action-setup@v2
        with:
          version: 8

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version-file: '.nvmrc'
          cache: 'pnpm'

      - name: Install dependencies
        run: pnpm install --frozen-lockfile

      - name: Run lint
        run: pnpm lint

      - name: Run typecheck
        run: pnpm typecheck

      - name: Run tests
        run: pnpm test

      - name: Run build
        run: pnpm build

      - name: Upload coverage
        uses: codecov/codecov-action@v3
        if: always()
        with:
          files: ./packages/*/coverage/lcov.info
          fail_ci_if_error: false
```

**Verification:**
```bash
# Verify YAML syntax
cat .github/workflows/ci.yml | head -20
# Push to branch and check Actions tab
```

**Done When:** CI workflow runs on push/PR

---

### Task 1.3.2: Configure Turborepo for monorepo builds

**Time:** 5 minutes | **Tokens:** ~3K

**Files to CREATE:**
- `turbo.json`

**Purpose:** Optimize monorepo builds with caching and parallel execution.

**Implementation:**

```json
// turbo.json
{
  "$schema": "https://turbo.build/schema.json",
  "globalDependencies": [".env*"],
  "tasks": {
    "build": {
      "dependsOn": ["^build"],
      "outputs": ["dist/**"],
      "cache": true
    },
    "test": {
      "dependsOn": ["build"],
      "outputs": ["coverage/**"],
      "cache": true
    },
    "lint": {
      "outputs": [],
      "cache": true
    },
    "typecheck": {
      "dependsOn": ["^build"],
      "outputs": [],
      "cache": true
    },
    "dev": {
      "cache": false,
      "persistent": true
    },
    "clean": {
      "cache": false
    }
  }
}
```

**Verification:**
```bash
pnpm build
pnpm build  # Second run should be cached (shows "FULL TURBO")
```

**Done When:** Turbo caches builds correctly

---

### Task 1.3.3: Create package stub directories

**Time:** 10 minutes | **Tokens:** ~6K

**Directories to CREATE with package.json, tsconfig.json, and src/index.ts:**
- `packages/answer-contract/`
- `packages/forge-c/`
- `packages/convergence/`
- `packages/figma-parser/`
- `packages/react-generator/`
- `packages/test-generator/`
- `packages/evidence-pack/`
- `packages/infrastructure/`
- `packages/integrations/`
- `packages/platform-ui/`

**Purpose:** Scaffold all package directories for the monorepo.

**Template for each package:**

```json
// packages/{name}/package.json
{
  "name": "@forge/{name}",
  "version": "0.1.0",
  "type": "module",
  "main": "./dist/index.js",
  "types": "./dist/index.d.ts",
  "exports": {
    ".": {
      "types": "./dist/index.d.ts",
      "import": "./dist/index.js"
    }
  },
  "files": ["dist"],
  "scripts": {
    "build": "tsc -p tsconfig.build.json",
    "test": "vitest run",
    "lint": "eslint src/",
    "typecheck": "tsc --noEmit",
    "clean": "rm -rf dist"
  },
  "dependencies": {
    "@forge/core": "workspace:*"
  },
  "devDependencies": {
    "vitest": "^1.0.0"
  }
}
```

```json
// packages/{name}/tsconfig.json
{
  "extends": "../../tsconfig.json",
  "compilerOptions": {
    "rootDir": "src",
    "outDir": "dist"
  },
  "include": ["src/**/*"],
  "exclude": ["node_modules", "dist", "**/*.test.ts"]
}
```

```json
// packages/{name}/tsconfig.build.json
{
  "extends": "./tsconfig.json",
  "compilerOptions": {
    "noEmit": false,
    "declaration": true,
    "declarationMap": true
  }
}
```

```typescript
// packages/{name}/src/index.ts
// Package exports will be implemented in subsequent epics
export const PACKAGE_NAME = '{name}';
export const PACKAGE_VERSION = '0.1.0';
```

**Verification:**
```bash
ls packages/  # Should show 11 directories
pnpm install
pnpm build
```

**Done When:** All 11 packages exist and `pnpm build` succeeds

---

## Epic 1 Completion Checklist

Before moving to Epic 2:

- [ ] All 11 tasks marked [x] in progress.md
- [ ] `pnpm install` succeeds
- [ ] `pnpm build` succeeds
- [ ] `pnpm lint` passes
- [ ] `pnpm test` runs (even with no tests)
- [ ] GitHub Actions CI passes (if repo exists)
- [ ] All 11 packages exist in `packages/` directory
- [ ] @forge/core exports: ForgeContext, ForgeConfig, ForgeResult, TokenTracker, logger

**Commit:** `git commit -m "Epic 1: Foundation complete"`

**Next:** Epic 2 - Answer Contract System
